-- for postgres DB
/*CREATE TABLE Employee (
  code INT PRIMARY KEY NOT NULL,
  name CHAR(20) NOT NULL,
  city CHAR(20)
); */

-- for MySQL
 
 CREATE  TABLE `test`.`employee` (
  `code` INT NOT NULL ,
  `name` VARCHAR(45) NOT NULL ,
  `city` VARCHAR(45) NOT NULL ,
  PRIMARY KEY (`idnew_table`) 
  );

